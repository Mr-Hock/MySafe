// HoolTaskmgr.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <windows.h>

int main(int argc, char** argv)
{
	if (argc == 1)
	{
		printf("��������ȷ��\n");
		//system("pause");
		return 0;
	}

	DWORD nTaskmgrPid = 0;
	DWORD nMySafePid = 0;
	DWORD nOpenClose = 0;

	sscanf_s(argv[1], "%d", &nTaskmgrPid);//argv[1] Ϊһ���������������������ID
	sscanf_s(argv[2], "%d", &nMySafePid);//argv[2] Ϊ�����������������Ľ���ID
	sscanf_s(argv[3], "%d", &nOpenClose);//argv[3] Ϊ�������������ؿ��� 0=�� 1=��

	HANDLE hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, nTaskmgrPid);
	if (hProc == NULL) {
		printf("��Taskmgrʧ�ܣ�\n");
		//system("pause");
		return 0;
	}

	HMODULE nModule = GetModuleHandleA("Kernel32.dll");//��ȡKernel32ģ����
	DWORD nAddr = (DWORD)GetProcAddress(nModule, "OpenProcess");//��ȡ������ַ

	if (nOpenClose)//�������HOOK
	{	//�����ڴ棬д��HoolCode
		LPVOID pHookAsm = VirtualAllocEx(hProc, NULL, 1, MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);

		DWORD nReadBuff = 0;
		SIZE_T nReadSize = 0;
		SIZE_T nWriteSize = 0;
		DWORD nOldProt;
		CHAR nHookCode[50]{};
		CHAR nJmpCode[6]{};

		ReadProcessMemory(hProc, (LPCVOID)(nAddr + 8), &nReadBuff, 1, &nReadSize);
		if (nReadBuff != 0xff)
		{
			VirtualFreeEx(hProc, pHookAsm, 1, MEM_RELEASE);
			CloseHandle(hProc);
			return 0;
		}

		ReadProcessMemory(hProc, (LPCVOID)(nAddr + 10), &nReadBuff, 4, &nReadSize);
		nReadBuff = nReadBuff + nAddr + 10;
		nReadBuff = nReadBuff + 4;//��ȡ���������ת���ĵ�ַ

		//cmp r8, nMySafePid
		nHookCode[0] = 0x49;
		nHookCode[1] = 0x81;
		nHookCode[2] = 0xf8;
		*(DWORD*)(nHookCode + 3) = nMySafePid;
		//je +8
		nHookCode[7] = 0x74;
		nHookCode[8] = 0x08;
		//push[nReadBuff]
		nHookCode[9] = 0xff;
		nHookCode[10] = 0x34;
		nHookCode[11] = 0x25;
		*(DWORD*)(nHookCode + 12) = nReadBuff;
		//ret
		nHookCode[16] = 0xc3;
		//xor rax,rax
		nHookCode[17] = 0x48;
		nHookCode[18] = 0x31;
		nHookCode[19] = 0xc0;
		//ret
		nHookCode[20] = 0xc3;
		//��HookCodeд���ڴ�
		WriteProcessMemory(hProc, pHookAsm, nHookCode, _countof(nHookCode), &nWriteSize);
		printf("HookCode��ַ��%X\n", (DWORD)pHookAsm);

		VirtualProtectEx(hProc, (LPVOID)(nAddr), 1, PAGE_EXECUTE_READWRITE, &nOldProt);
		//push pHookAsm
		nJmpCode[0] = 0x68;
		*(DWORD*)(nJmpCode + 1) = (DWORD)pHookAsm;
		//ret
		nJmpCode[5] = 0xc3;
		WriteProcessMemory(hProc, (LPVOID)(nAddr + 8), nJmpCode, _countof(nJmpCode), &nWriteSize);
		VirtualProtectEx(hProc, (LPVOID)(nAddr), 1, nOldProt, &nOldProt);

		//02B50000 - 49 81 F8 C01E0000 - cmp r8, 00001EC0
		//02B50007 - 74 08 - je 02B50011
		//02B50009 - FF 34 25 10D4BB77 - push[kernel32.UnhandledExceptionFilter + 1960]
		//02B50010 - C3 - ret
		//02B50011 - 48 31 C0 - xor rax, rax
		//02B50014 - C3 - ret

		printf("Hook�ɹ���\n", argc);
		//system("pause");
	}
	else
	{
		DWORD nOldProt;
		CHAR nReadBuff[6]{};
		SIZE_T nReadSize = 0;
		SIZE_T nWriteSize = 0;

		ReadProcessMemory((HANDLE)-1, (LPCVOID)(nAddr + 8), &nReadBuff, 6, &nReadSize);

		VirtualProtectEx(hProc, (LPVOID)(nAddr), 1, PAGE_EXECUTE_READWRITE, &nOldProt);
		WriteProcessMemory(hProc, (LPVOID)(nAddr + 8), nReadBuff, _countof(nReadBuff), &nWriteSize);
		VirtualProtectEx(hProc, (LPVOID)(nAddr), 1, nOldProt, &nOldProt);

		printf("UnHook�ɹ���\n", argc);
		//system("pause");

	}


	CloseHandle(hProc);

    return 0;
}

